<?php
session_start();
$mysqli = require __DIR__ . "/dbconnection.php";

if (isset($_SESSION["accountID"])) {
    $query = "SELECT * FROM accounts
            WHERE accountID = {$_SESSION["accountID"]}";

    $result = $mysqli->query($query);

    $user = $result->fetch_assoc();

    $hasUploadedDocuments = false;
    $query = "SELECT * FROM document WHERE account_id = {$_SESSION["accountID"]}";
    $result = $mysqli->query($query);
    if ($result->num_rows > 0) {
        $hasUploadedDocuments = true;
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/reqlogs.css">
    <link rel="stylesheet" href="public/css/sidebar.css">
    <title>Logs</title>
</head>

<body>

<div class="container-fluid">
        <div class="row">

            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <h5 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        Requester
                    </h5>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="requester.php">
                                Upload Documents
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="reqlogs.php">
                                View Logs
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="reqnotifs.php">
                                Notifications
                            </a>
                        </li>
                    </ul>
                </div>
                <form action="logout.php" method="POST" class="logout-btn custom-logout-btn">
                    <input type="submit" value="Logout" class="btn btn-danger">
                </form>

            </nav>
            


            <!-- Main Content -->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
                <div class="text-right">
                    <p class="text-info">Logged in as: <?php echo $user["email"]; ?></p>
                </div>

            
            <h2 class='mt-4'>Uploaded Documents</h2>
        <?php
        $query = "SELECT * FROM document WHERE account_id = {$_SESSION["accountID"]}";
        $result = $mysqli->query($query);

        if ($result->num_rows > 0) {
            echo "<table class='table table-bordered'>
                <thead class='thead-dark'>
                    <tr>
                        <th>document_title</th>
                        <th>document_name</th>
                        <th>document_type</th>
                        <th>document_size</th>
                        <th>upload_datetime</th>
                    </tr>
                </thead>
                <tbody>";

            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["document_title"] . "</td>
                    <td>" . $row["document_name"] . "</td>
                    <td>" . $row["document_type"] . "</td>
                    <td>" . $row["document_size"] . "</td>
                    <td>" . $row["upload_datetime"] . "</td>
                </tr>";
            }

            echo "</tbody></table>";
        } else {
            echo "<p class='mt-3'>No uploaded documents to display.</p>";
        }

        echo "<h2 class='mt-4'>Reuploaded Documents</h2>";
        $query = "SELECT * FROM reuploaddocs";
        $result = $mysqli->query($query);

        if ($result->num_rows > 0) {
            echo "<table class='table table-bordered'>
                <thead class='thead-dark'>
                    <tr>
                        <th>document_title</th>
                        <th>account_id</th>
                        <th>document_name</th>
                        <th>document_type</th>
                        <th>document_size</th>
                        <th>upload_datetime</th>
                    </tr>
                </thead>
                <tbody>";

            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["document_title"] . "</td>
                    <td>" . $row["account_id"] . "</td>
                    <td>" . $row["document_name"] . "</td>
                    <td>" . $row["document_type"] . "</td>
                    <td>" . $row["document_size"] . "</td>
                    <td>" . $row["upload_datetime"] . "</td>
                </tr>";
            }
        
            echo "</tbody></table>";
        } else {
            echo "<p class='mt-3'>No reuploaded documents to display.</p>";
        }
        ?>
        

    </div>
                        
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <footer class="footer mt-4">
        <div class="container text-center">
            <p>&copy; 2023 ZestyWithTheBesties All rights reserved.</p>
        </div>
    </footer>

</body>

</html>
