<?php
session_start();
$mysqli = require __DIR__ . "/dbconnection.php";


// Check if the user is not logged in
if (!isset($_SESSION['accountID']) || $_SESSION["roles"] !== "requester") {
    // Redirect the user back to the login page with an error message
    header("Location: login.php?error=Please login first");
    exit();
}


$query = "SELECT * FROM accounts
        WHERE accountID = {$_SESSION["requesterID"]}";

$result = $mysqli->query($query);

$user = $result->fetch_assoc();

$hasUploadedDocuments = false;
$query = "SELECT * FROM document WHERE account_id = {$_SESSION["requesterID"]}";
$result = $mysqli->query($query);
if ($result->num_rows > 0) {
    $hasUploadedDocuments = true;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/req.css">
    <link rel="stylesheet" href="public/css/sidebars.css">
    
    
    <title>Requester page</title>
</head>

<body>

    <div class="container-fluid">
        <div class="row">
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <h5 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        Requester
                    </h5>
                    <div class="text-right">
                    <p class="text">Logged in as: <?php echo $user["firstName"]; ?></p>
                </div>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="#">
                                Upload Documents
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="reqlogs.php">
                                View Logs
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="reqnotifs.php">
                                Notifications
                            </a>
                        </li>
                    </ul>
                </div>
                <form action="logout.php" method="POST" class="logout-btn custom-logout-btn">
                    <input type="submit" value="Logout" class="btn btn-danger">
                </form>
            </nav>
        </div>
</div>
            


            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
                

        <div class="container">        

        <h1 class="mt-4">Upload Document</h1>

        <form action="upload.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="documentTitle">Document Title</label>
                <input type="text" class="form-control" name="documenttitle" required>
            </div>
            <div class="form-group">
                <label for="file" class="form-label">Select File</label>
                <input type="file" class="form-control-file" name="file" id="file">
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Upload File</button>
        </form>

        <h2 class='mt-4'></h2>
        <?php
        $query = "SELECT * FROM document WHERE account_id = {$_SESSION["accountID"]}";
        $result = $mysqli->query($query);

        echo "<h2 class='mt-4'>Approved Documents</h2>";

        $query = "SELECT t.transactionID, t.documentID, t.reviewerID,
                    d.document_id,
                    d.document_title,
                    d.account_id,
                    d.document_name,
                    d.document_type
                FROM
                    transaction t
                INNER JOIN document d ON t.documentID = d.document_id
                WHERE
                    d.account_id = {$_SESSION["accountID"]} AND t.statusOfDocument = 'approve'";

        $result = $mysqli->query($query);

        if ($result->num_rows > 0) {
            echo "<table class='table table-bordered'>
                    <thead class='thead'>
                        <tr>
                            <th>Document Title</th>
                            <th>Reviewer ID</th>
                            <th>Document Name</th>
                            <th>Document Type</th>
                        </tr>
                    </thead>
                    <tbody>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['document_title']}</td>
                        <td>{$row['reviewerID']}</td>
                        <td>{$row['document_name']}</td>
                        <td>{$row['document_type']}</td>
                        
                    </tr>";
            }

            echo "</tbody></table>";
        } else {
            echo "<p class='mt-3'>No approved documents to display.</p>";
        }
        


        echo "<h2 class='mt-4'>Rejected Documents</h2>";

        $query = "SELECT * FROM document 
                  JOIN transaction ON document.document_id = transaction.documentID
                  WHERE document.account_id = {$_SESSION["accountID"]} AND transaction.statusOfDocument = 'reject'";
        $result = $mysqli->query($query);
        
        if ($result->num_rows > 0) {
            echo "<table class='table table-bordered'>
                <thead class='thead'>
                    <tr>
                        <th>Document Title</th>
                        <th>Reviewer ID</th>
                        <th>Document Name</th>
                        <th>Document Type</th>
                        <th>Reviewer Comment</th>
                    </tr>
                </thead>
                <tbody>";
        
            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["document_title"] . "</td>
                    <td>" . $row["reviewerID"] . "</td>
                    <td>" . $row["document_name"] . "</td>
                    <td>" . $row["document_type"] . "</td>
                    <td>" . $row["comments"] . "</td>
                </tr>";
            }
        
            echo "</tbody></table>";
        
            // Add the "Reupload Document" section
            echo "<h2 class='mt-4'>Reupload Document</h2>";
            echo "<form action='reupload.php' method='POST' enctype='multipart/form-data'>
                    <div class='form-group'>
                        <label for='reuploaddocumentTitle'>Document Title</label>
                        <input type='text' class='form-control' name='reuploadtitle' required>
                    </div>
                    <div class='form-group'>
                        <label for='file' class='form-label'>Select File</label>
                        <input type='file' class='form-control-file' name='file' id='file'>
                    </div>
                    <button type='submit' name='reupload' class='btn btn-primary'>Reupload Document</button>
                  </form>";
        } else {
            echo "<p class='mt-3'>No rejected documents to display.</p>";
        }
?>
    </div>
</main>

    <!-- Bootstrap JS (optional, if needed) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <footer>
        <p>&copy; 2023 ZestyWithTheBesties. All rights reserved.</p>
    </footer>
    
    </body>
</html>
