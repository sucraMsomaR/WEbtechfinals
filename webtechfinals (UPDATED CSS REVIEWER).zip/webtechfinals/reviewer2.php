<?php
session_start();
$mysqli = require __DIR__ . "/dbconnection.php";

if (!isset($_SESSION["reviewer2ID"])) {
    header("Location: login.php"); 
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviewer page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/rev1.css">
    <link rel="stylesheet" href="public/css/sidebar.css">
</head>

<body>

<div class="container-fluid">
        <div class="row">
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                <div class="sidebar-sticky">
                    <h5 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                        Office 2
                    </h5>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="reviewer2.php">
                                Review Documents
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                View Logs
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                Notifications
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

    <div class="container">

        <div class="text-right">
            <form action="logout.php" method="POST" class="logout-btn">
                <input type="submit" value="Logout" class="btn btn-danger">
            </form>
        </div>

        <h1 class="mt-4">Approved Documents (Reviewer 2)</h1>

        <?php
        
        $query = "SELECT t.transactionID, t.documentID, t.reviewerID,
d.document_id,
d.document_title,
d.account_id,
d.document_name,
d.document_type
FROM
transaction t
INNER JOIN document d ON t.documentID = d.document_id
WHERE
t.statusOfDocument = 'approve'";

$result = $mysqli->query($query);

if ($result->num_rows > 0) {
// Display the approved documents in a table
echo "<table>
<thead>
    <tr>
        <th>Transaction ID</th>
        <th>Document ID</th>
        <th>Reviewer ID</th>
        <th>Document Title</th>
        <th>Account ID</th>
        <th>Document Name</th>
        <th>Document Type</th>
    </tr>
</thead>
<tbody>";

while ($row = $result->fetch_assoc()) {
echo "<tr>
    <td>{$row['transactionID']}</td>
    <td>{$row['documentID']}</td>
    <td>{$row['reviewerID']}</td>
    <td>{$row['document_title']}</td>
    <td>{$row['account_id']}</td>
    <td>{$row['document_name']}</td>
    <td>{$row['document_type']}</td>
  </tr>";
}

echo "</tbody></table>";
} else {
echo "No approved documents found.";
}

// Close your database connection
$mysqli->close();

        ?>

    </div>

</body>

</html>