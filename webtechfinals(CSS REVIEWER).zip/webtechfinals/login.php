<?php
session_start();
$mysqli = require __DIR__ . "/dbconnection.php";

$errors = []; // Create an array to store error messages

// Check if the user is already logged in
if (isset($_SESSION['accountID'])) {
    $errors[] = "User is already logged in.";
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the submitted credentials
    $username = $_POST["email"];
    $password = $_POST["password"];

    $query = "SELECT * FROM accounts WHERE email= ? AND password=?";
    $stmt = $mysqli->prepare($query);

    if ($stmt === false) {
        die('Error in SQL query: ' . $mysqli->error);
    }

    $stmt->bind_param('ss', $username, $password);

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
    // Valid credentials
    $row = $result->fetch_assoc();

    // Update status to 'online'
    $updateStatus = "UPDATE accounts SET status = 'online' WHERE accountID = ?";
    $updateStmt = $mysqli->prepare($updateStatus);
    $updateStmt->bind_param('s', $row['accountID']);
    $updateStmt->execute();
    $updateStmt->close();

    // Set session variables, including 'email' and role-specific ID
    $_SESSION['accountID'] = $row['accountID'];
    $_SESSION["roles"] = $row["roles"];
    $_SESSION["email"] = $row["email"]; 

    // Differentiate between requester and reviewer sessions
    if ($_SESSION["roles"] === "admin") {
    } else if ($_SESSION["roles"] === "requester") {
        $_SESSION["requesterID"] = $row['accountID'];
        header("Location: requester.php");
        exit();
    } else if ($_SESSION["roles"] === "reviewer") {
        $_SESSION["reviewerID"] = $row['accountID'];
        header("Location: reviewer.php");
        exit();

    }
} else {
    // Invalid credentials, add an error message
    $errors[] = "Invalid credentials. Please check your username and password.";
}
    $stmt->close();
    $mysqli->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content=""width=device-width, initial-scale="1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>
    <div class="container">
    <form action="login.php" method="POST" class="form">
        <h2>MEMBER LOGIN</h2>
        <input type="email" name="email" class="box" placeholder="Email"> 
        <input type="password" name="password" class="box" placeholder="Password">
        <input type="submit" value="LOGIN" id="submit">
    </form>
    <div class="side">
        <img src="res/image/Logo.png" alt="Logo">
        <img src="public/res/image/Logo.png" alt="Logo">
    </div>
</div>
<div class="notification"></div> <!-- Notification element -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
    const notification = document.querySelector('.notification');

    <?php
    // Display errors here
    foreach ($errors as $error) {
        echo "notification.textContent = '$error';";
        echo "notification.style.display = 'block';";
    }

    // Check for redirect error message
    $redirectError = isset($_GET['error']) ? $_GET['error'] : '';
    if ($redirectError) {
        echo "notification.textContent = '$redirectError';";
        echo "notification.style.display = 'block';";
    }
    ?>

    // Hide the notification after 3 seconds
    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
});
</script>

</body>
</html>

