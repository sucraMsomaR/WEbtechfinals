<?php
session_start();
$mysqli = require __DIR__ . "/dbconnection.php";

if (isset($_SESSION['accountID'])) {
    // Update status to 'offline' before closing the session
    $updateStatus = "UPDATE accounts SET status = 'offline' WHERE accountID = ?";
    $updateStmt = $mysqli->prepare($updateStatus);
    $updateStmt->bind_param('i', $_SESSION['accountID']); 
    $updateStmt->execute();
    $updateStmt->close();
}

// Destroy the session
session_destroy();

// Redirect to the login.html page after logout
header("Location: login.php");
exit;
?>
