<?php
$mysqli = require __DIR__ . "/dbconnection.php";

date_default_timezone_set('Asia/Shanghai');

session_start();

if (isset($_SESSION["accountID"])) {
    $query = "SELECT * FROM accounts WHERE accountID = {$_SESSION["accountID"]}";
    $result = $mysqli->query($query);
    $user = $result->fetch_assoc();

    if (isset($_POST['reupload'])) {
        $reuploaddocumentTitle = $_POST["reuploadtitle"];
          // Determine the latest version of the document
          $latestVersionQuery = "SELECT MAX(version) FROM document WHERE account_id = ? AND document_title = ?";
          $latestVersionStmt = $mysqli->prepare($latestVersionQuery);
          $latestVersionStmt->bind_param("is", $user["accountID"], $reuploaddocumentTitle);
          $latestVersionStmt->execute();
          $latestVersionStmt->bind_result($latestVersion);
          $latestVersionStmt->fetch();
          $latestVersionStmt->close();

          // Increment the version for the new upload
          $version = $latestVersion + 1;

        if (isset($_FILES["file"]) && $_FILES["file"]["error"] == UPLOAD_ERR_OK) {
            $fileName = $_FILES["file"]["name"];
            $fileTmpName = $_FILES["file"]["tmp_name"];
            $fileType = $_FILES["file"]["type"];
            $fileSize = $_FILES["file"]["size"];
            $fileData = file_get_contents($fileTmpName); // Updated this line
            $fileExt = explode('.', $fileName);
            $fileLowerExt = strtolower(end($fileExt));

            $allowed_types = array("jpg", "jpeg", "png", "gif", "pdf", "txt", "docx");

            if (!in_array($fileLowerExt, $allowed_types)) {
                echo "<script>alert('This type of file cannot be uploaded!');
                      document.location.href ='requester.php';</script>";
                exit(); // Added exit() to stop execution
            } else {
                if ($fileSize < 500000) {
                    $uploadDateTime = date("Y-m-d h:i:s A");
                    $sql = "INSERT INTO document (document_name, document_title, document_type, document_size, account_id, document_blob, upload_datetime, version) VALUES (?, ?, ?, ?, ?, ?,?, ? )";
                    $stmt = $mysqli->prepare($sql);
                    $stmt->bind_param("sssssssi", $fileName, $reuploaddocumentTitle, $fileType, $fileSize, $user["accountID"], $fileData, $uploadDateTime, $version);
                    $stmt->execute();

                    if ($stmt->errno) {
                        echo "Error: " . $stmt->error;
                    } else {
                        $stmt->close();
                        $loggedInUserEmail = isset($user["email"]) ? $user["email"] : "Unknown User";

                        $_SESSION["reuploadNotification"] = "User '$loggedInUserEmail' has reuploaded a document!";
                        echo "<script>alert('Your file has been reuploaded successfully!');
                               document.location.href ='requester.php';</script>";
                        exit(); // Added exit() to stop execution
                    }
                } else {
                    echo "<script>alert('Your file is too big!');
                           document.location.href ='requester.php';</script>";
                    exit(); // Added exit() to stop execution
                }
            }
        } else {
            echo "<script>alert('There was an error in uploading your file!');
                  document.location.href ='requester.php';</script>";
            exit(); // Added exit() to stop execution
        }
    }
}

// Redirect to requester.php if the conditions are not met
header("Location: requester.php");
exit();
?>
