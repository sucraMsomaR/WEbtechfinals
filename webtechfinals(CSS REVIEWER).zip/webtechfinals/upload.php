<?php
$mysqli = require __DIR__ . "/dbconnection.php";

date_default_timezone_set('Asia/Shanghai');

session_start();

if (isset($_SESSION["accountID"])) {
    $query = "SELECT * FROM accounts WHERE accountID = {$_SESSION["accountID"]}";
    $result = $mysqli->query($query);
    $user = $result->fetch_assoc();

    if (isset($_POST['submit'])) {
        $documentTitle = $_POST["documenttitle"];
        if (isset($_FILES["file"]) && $_FILES["file"]["error"] == UPLOAD_ERR_OK) {
            $fileName = $_FILES["file"]["name"];
            $fileTmpName = $_FILES["file"]["tmp_name"];
            $fileType = $_FILES["file"]["type"];
            $fileSize = $_FILES["file"]["size"];
            $fileData = file_get_contents($_FILES['file']['tmp_name']);
            $fileExt = explode('.', $fileName);
            $fileLowerExt = strtolower(end($fileExt));

            $allowed_types = array("jpg", "jpeg", "png", "gif", "pdf", "txt", "docx");
            if (!in_array($fileLowerExt, $allowed_types)) {
                echo "<script>alert('This type of file cannot be uploaded!');
                      document.location.href ='requester.php';</script>";
            } else {
                if ($fileSize < 500000) {
                    $uploadFolder = __DIR__ . "/uploadedfiles/";
                    $destination = $uploadFolder . $fileName;

                    move_uploaded_file($fileTmpName, $destination);

                    $file_contents = file_get_contents($destination);
                    $file_contents = addslashes($file_contents);

                    $uploadDateTime = date("Y-m-d h:i:s A");
                    $sql = "INSERT INTO document (document_name, document_title, document_type, document_size, account_id, document_blob, upload_datetime) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    $stmt = $mysqli->prepare($sql);
                    $stmt->bind_param("ssssiss", $fileName, $documentTitle, $fileType, $fileSize, $user["accountID"], $file_contents, $uploadDateTime);
                    $stmt->execute();

                    if ($stmt->errno) {
                        echo "Error: " . $stmt->error;
                    }

                    $stmt->close();
                    $loggedInUserEmail = isset($user["email"]) ? $user["email"] : "Unknown User";

                    // Add a notification for successful upload
                    $_SESSION["uploadNotification"] = "User '$loggedInUserEmail' has uploaded a document!";
                    header("Location: upload.php");
                    exit();
                } else {
                    echo "<script>alert('Your file is too big!');
                           document.location.href ='requester.php';</script>";
                }
            }
        } else {
            echo "<script>alert('There was an error in uploading your file!');
                  document.location.href ='requester.php';</script>";
        }
    } else {
        echo "<script>alert('Your file has been uploaded successfully!');
               document.location.href ='requester.php';</script>";
    }
}
?>
