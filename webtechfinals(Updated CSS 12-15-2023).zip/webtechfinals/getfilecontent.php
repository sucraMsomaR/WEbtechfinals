<?php
$documentID = $_POST['documentID'];

// Fetch file content based on $documentID from the database or file system
// Replace the following line with your logic to retrieve file content
$fileContent = "Content for document ID $documentID";

echo htmlentities($fileContent); // Ensure proper HTML escaping
?>
