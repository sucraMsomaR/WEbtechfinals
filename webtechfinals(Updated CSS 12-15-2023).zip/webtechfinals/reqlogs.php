<?php
session_start();
$mysqli = require __DIR__ . "/dbconnection.php";

if (isset($_SESSION["requesterID"])) {
    $query = "SELECT * FROM accounts WHERE accountID = {$_SESSION["requesterID"]}";
    $result = $mysqli->query($query);
    $user = $result->fetch_assoc();
    $hasUploadedDocuments = false;
    $query = "SELECT * FROM document WHERE account_id = {$_SESSION["accountID"]}";
    $result = $mysqli->query($query);
    if ($result->num_rows > 0) {
        $hasUploadedDocuments = true;
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reviewer</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="...">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="public/css/reqlogs.css">
</head>

<body>

<nav class="navbar navbar-expand-lg">
    <div class="container">
    <h5 class="navbar-heading d-flex justify-content-between px-4 mb-1"> Requester
    </h5>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button> 
      <div class="text">
        <p class="text">Logged in as: <?php echo $user["firstName"]; ?></p>
    </div>
        <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="requester.php">Upload Documents</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="reqlogs.php">View Logs</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="reqnotifs.php"> Notifications</a>
          </li>
        </ul>
      </div>
    </div>
    </div>
  </nav>

            <!-- Main Content -->

                <div class="container">

                    <h2 class='mt-4'>Uploaded Documents</h2>
                    <?php
                    $query = "SELECT * FROM document WHERE account_id = {$_SESSION["accountID"]}";
                    $result = $mysqli->query($query);

                    if ($result->num_rows > 0) {
                        echo "<table class='table table-bordered'>
                            <thead class='thead'>
                                <tr>
                                    <th>Document Title</th>
                                    <th>Document Name</th>
                                    <th>Document Type</th>
                                    <th>Document Size</th>
                                    <th>Upload Date Time</th>
                                    <th>Version</th>
                                </tr>
                            </thead>
                            <tbody>";

                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>" . $row["document_title"] . "</td>
                                <td>" . $row["document_name"] . "</td>
                                <td>" . $row["document_type"] . "</td>
                                <td>" . $row["document_size"] . "</td>
                                <td>" . $row["upload_datetime"] . "</td>
                                <td>" . $row["version"] . "</td>
                            </tr>";
                        }

                        echo "</tbody></table>";
                    } else {
                        echo "<p class='mt-3'>No uploaded documents to display.</p>";
                    }
                    ?>


                    <!-- Display Approved Documents -->
                    <?php
                    echo "<h2 class='mt-4'>Approved Documents</h2>";
                    $query = "SELECT t.transactionID, t.documentID, t.reviewerID,
                                d.document_id,
                                d.document_title,
                                d.account_id,
                                d.document_name,
                                d.document_type,
                                r.officename  -- Include the officename from the reviewer table
                            FROM
                                transaction t
                            INNER JOIN document d ON t.documentID = d.document_id
                            INNER JOIN reviewer r ON t.reviewerID = r.reviewerID -- Join with the reviewer table
                            WHERE
                                d.account_id = {$_SESSION["accountID"]} AND t.statusOfDocument = 'approve'";

                    $result = $mysqli->query($query);

                    if ($result->num_rows > 0) {
                        echo "<table class='table table-bordered'>
                                    <thead class='thead'>
                                        <tr>
                                            <th>Document Title</th>
                                            <th>Reviewer Office</th> <!-- Change the column name -->
                                            <th>Document Name</th>
                                            <th>Document Type</th>
                                        </tr>
                                    </thead>
                                    <tbody>";

                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                        <td>{$row['document_title']}</td>
                                        <td>{$row['officename']}</td> <!-- Display officename instead of reviewerID -->
                                        <td>{$row['document_name']}</td>
                                        <td>{$row['document_type']}</td>
                                    </tr>";
                        }

                        echo "</tbody></table>";
                    } else {
                        echo "<p class='mt-3'>No approved documents to display.</p>";
                    }
                    ?>


                    <!-- Display Rejected Documents -->
                    <?php
                    echo "<h2 class='mt-4'>Rejected Documents</h2>";
                    $query = "SELECT d.document_title, t.reviewerID, d.document_name, d.document_type, t.comments, r.officename
                              FROM document d
                              JOIN transaction t ON d.document_id = t.documentID
                              JOIN reviewer r ON t.reviewerID = r.reviewerID
                              WHERE d.account_id = {$_SESSION["accountID"]} AND t.statusOfDocument = 'reject'";

                    $result = $mysqli->query($query);

                    if ($result->num_rows > 0) {
                        echo "<table class='table table-bordered'>
                                <thead class='thead'>
                                    <tr>
                                        <th>Document Title</th>
                                        <th>Reviewer Office ID</th> <!-- Change the column name -->
                                        <th>Document Name</th>
                                        <th>Document Type</th>
                                        <th>Reviewer Comment</th>
                                    </tr>
                                </thead>
                                <tbody>";

                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>
                                        <td>" . $row["document_title"] . "</td>
                                        <td>" . $row["officename"] . "</td>
                                        <td>
                                            <a href='#' class='file-link' data-toggle='modal' data-target='#fileModal' data-file='uploadedfiles/{$row["document_name"]}'>{$row["document_name"]}</a>
                                        </td>
                                        <td>" . $row["document_type"] . "</td>
                                    </tr>";
                                }

                        echo "</tbody></table>";
                    } else {
                        echo "<p class='mt-3'>No rejected documents to display.</p>";
                    }
                    ?>

                </div>

                <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="..." ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
                <script>
    $(document).ready(function () {
        $('.file-link').click(function (e) {
            e.preventDefault();
            var fileUrl = $(this).data('file');
            var fileName = $(this).text();
            var documentID = $(this).closest('tr').find('input[name="document_id"]').val();

            // Set the modal title to the file name
            $('#fileModalLabel').text('Document Preview - ' + fileName);

            // Set the iframe source to the file URL
            $('#fileViewer').attr('src', fileUrl);

            // Set the document ID in the hidden input field inside the modal
            $('#modalDocumentID').val(documentID);
        });

        $('#fileModal').on('hidden.bs.modal', function () {
            // Reset the modal title and document ID when the modal is closed
            $('#fileModalLabel').text('Document Preview');
            $('#fileViewer').attr('src', '');
            $('#modalDocumentID').val('');
        });
    });
</script>

                <form action="logout.php" method="POST" class="logout-btn custom-logout-btn">
                    <input type="submit" value="Logout" class="btn btn-danger">
                </form>

        
        </div>
    </div>
    <div class="modal fade" id="fileModal" tabindex="-1" role="dialog" aria-labelledby="fileModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" style="max-width: 90%;" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="fileModalLabel">Document Preview</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <iframe id="fileViewer" width="100%" height="800px" frameborder="0"></iframe>
            </div>
        </div>
    </div>
</div>         
<footer>
    <p>&copy; 2023 ZestyWithTheBesties. All rights reserved.</p>
</footer>       
</body>

</html>
