<?php
session_start();
$mysqli = require __DIR__ . "/dbconnection.php";

// Check if the user is not logged in
if (!isset($_SESSION['accountID']) || $_SESSION["roles"] !== "requester") {
    // Redirect the user back to the login page with an error message
    header("Location: login.php?error=Please login first");
    exit();
}

$query = "SELECT * FROM accounts WHERE accountID = {$_SESSION["requesterID"]}";
$result = $mysqli->query($query);
$user = $result->fetch_assoc();
$hasUploadedDocuments = false;
$query = "SELECT * FROM document WHERE account_id = {$_SESSION["requesterID"]}";
$result = $mysqli->query($query);
if ($result->num_rows > 0) {
    $hasUploadedDocuments = true;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reviewer</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="...">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="public/css/reqs.css">
</head>

<body>

<nav class="navbar navbar-expand-lg">
    <div class="container">
    <h5 class="navbar-heading d-flex justify-content-between px-4 mb-1"> Requester
    </h5>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button> 
      <div class="text">
        <p class="text">Logged in as: <?php echo $user["firstName"]; ?></p>
    </div>
        <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="requester.php">Upload Documents</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="reqlogs.php">View Logs</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="reqnotifs.php"> Notifications</a>
          </li>
        </ul>
      </div>
    </div>
    </div>
  </nav>

        <div class="container">
            <h1 class="mt-4">Upload Document</h1>
            <form action="upload.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="documentTitle">Document Title</label>
                    <input type="text" class="form-control" name="documenttitle" required>
                </div>
                <div class="form-group">
                    <label for="file" class="form-label">Select File</label>
                    <input type="file" class="form-control-file" name="file" id="file">
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Upload File</button>
            </form>

            <!-- Reupload Document Section -->
            <h2 class='mt-4'>Reupload Document</h2>
            <form action='reupload.php' method='POST' enctype='multipart/form-data'>
                <div class='form-group'>
                    <label for='reuploaddocumentTitle'>Document Title</label>
                    <input type='text' class='form-control' name='reuploadtitle' required>
                </div>
                <div class='form-group'>
                    <label for='file' class='form-label'>Select File</label>
                    <input type='file' class='form-control-file' name='file' id='file'>
                </div>
                <button type='submit' name='reupload' class='btn btn-primary'>Reupload Document</button>
            </form>
        </div>
        <form action="logout.php" method="POST" class="logout-btn custom-logout-btn">
                    <input type="submit" value="Logout" class="btn btn-danger">
                </form>
  

    <!-- Bootstrap JS (optional, if needed) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="..." ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <footer>
        <p>&copy; 2023 ZestyWithTheBesties. All rights reserved.</p>
    </footer>

</body>

</html>
