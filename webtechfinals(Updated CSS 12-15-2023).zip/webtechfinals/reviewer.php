<?php
session_start();
$mysqli = require __DIR__ . "/dbconnection.php";

if (!isset($_SESSION["reviewerID"])) {
    header("Location: login.php");
    exit();
}

$query = "SELECT r.*, a.* FROM reviewer r
          JOIN accounts a ON r.reviewerID = a.accountID
          WHERE r.reviewerID = {$_SESSION["reviewerID"]}";

$result = $mysqli->query($query);

$user = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Process form submissions from reviewers
    if (isset($_POST["approve"]) && isset($_POST["document_id"])) {
        $documentID = $_POST["document_id"];

        // Get reviewer ID from the session or any other way you handle reviewers
        $reviewerID = $_SESSION["accountID"];
        $dateReviewed = date("Y-m-d h:i:s A");
        $dateAccepted = date("Y-m-d h:i:s A");
        
        $selectofficeQuery = "SELECT OfficeID FROM reviewer WHERE reviewerID = ?";
        $selectofficeStmt = $mysqli->prepare($selectofficeQuery);
        $selectofficeStmt->bind_param("i", $reviewerID);
        $selectofficeStmt->execute();
        $officeIDResult = $selectofficeStmt->get_result();

    // Check if the query was successful
    if ($officeIDResult && $officeIDRow = $officeIDResult->fetch_assoc()) {
        $officeID = $officeIDRow["OfficeID"];
       
        $comment = isset($_POST["review_comment"]) ? $_POST["review_comment"] : '';
        $insertCommentQuery = "INSERT INTO transaction (documentID, reviewerID, Office_ID, dateReviewed, dateAccepted, comments, statusOfDocument) VALUES (?, ?, ?, ?, ?, ?, 'approve')";
        $commentStmt = $mysqli->prepare($insertCommentQuery);
        $commentStmt->bind_param("iiisss", $documentID, $reviewerID, $officeID, $dateReviewed, $dateAccepted, $comment);
        $commentStmt->execute();
        $commentStmt->close();

        $updateQuery = "UPDATE transaction SET statusOfDocument = 'approve' WHERE transactionID = ?";
        $updateStmt = $mysqli->prepare($updateQuery);
        $updateStmt->bind_param('i', $transactionID);
        $updateStmt->execute();
        $updateStmt->close();

            // Add a notification for approval
            $notification = "Document ID $documentID has been approved!";
            $_SESSION["notifications"][] = $notification;

            // Redirect to requests.php after updating the OfficeID
            header("Location: reviewer.php");
            exit();
    }

}elseif (isset($_POST["reject"]) && isset($_POST["document_id"])) {
    $documentID = $_POST["document_id"];

    // Get reviewer ID and office ID from the session or any other way you handle reviewers
    $reviewerID = $_SESSION["reviewerID"];

    // Fetch the office ID from the reviewer table
    $selectofficeQuery = "SELECT OfficeID FROM reviewer WHERE reviewerID = ?";
    $selectofficeStmt = $mysqli->prepare($selectofficeQuery);
    $selectofficeStmt->bind_param("i", $reviewerID);
    $selectofficeStmt->execute();
    $officeIDResult = $selectofficeStmt->get_result();

    // Check if the query was successful
    if ($officeIDResult && $officeIDRow = $officeIDResult->fetch_assoc()) {
        $officeID = $officeIDRow["OfficeID"];

        $dateReviewed = date("Y-m-d h:i:s A");

        // Insert the review transaction into the database
        $comment = isset($_POST["review_comment"]) ? $_POST["review_comment"] : '';
        $insertCommentQuery = "INSERT INTO transaction (documentID, reviewerID, Office_ID, dateReviewed, comments, statusOfDocument) VALUES (?, ?, ?, ?, ?, 'reject')";
        $commentStmt = $mysqli->prepare($insertCommentQuery);
        $commentStmt->bind_param("iiiss", $documentID, $reviewerID, $officeID, $dateReviewed, $comment);
        $commentStmt->execute();
        $commentStmt->close();

        // Update the status and comment in the document table
        $updateQuery = "UPDATE transaction SET statusOfDocument = 'reject' WHERE transactionID = ?";
        $updateStmt = $mysqli->prepare($updateQuery);
        $updateStmt->bind_param('i', $transactionID);
        $updateStmt->execute();
        $updateStmt->close();

        // Add a notification for rejection
        $notification = "Document ID $documentID has been rejected.";
        $_SESSION["notifications"][] = $notification;

        header("Location: reviewer.php");
        exit();
    } else {
        echo "Error fetching office ID: " . $mysqli->error;
        // Handle the error as needed
    }
}
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reviewer</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="...">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="public/css/reviewer.css">
</head>

<body>
<nav class="navbar navbar-expand-lg">
    <div class="container">
    <h5 class="navbar-heading d-flex justify-content-between px-4 mb-1">
        <?php echo $user["officeName"]; ?>
    </h5>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button> 
      <div class="text">
        <p class="text">Logged in as: <?php echo $user["firstName"]; ?></p>
    </div>
        <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="reviewer.php">Review Documents</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="revlogs.php">View Logs</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="revnotifs.php"> Notifications</a>
          </li>
        </ul>
      </div>
    </div>
    </div>
  </nav>

    
  <div class="container">
                    <h1 class="mt-4">Review Documents</h1>

                    <?php
                    // Fetch documents pending review
                    if ($user["OfficeID"] == 1) {
                        // Fetch documents pending review for OfficeID 1
                        $query = "SELECT d.*, a.email
                                  FROM document d
                                  JOIN accounts a ON d.account_id = a.accountID
                                  WHERE d.document_id NOT IN (SELECT documentID FROM transaction)";
                        $result = $mysqli->query($query);

                    if ($result->num_rows > 0) {
                        echo "<table class='table table-bordered'>
                        <thead class='thead-dark'>
                            <tr>
                                <th>Document ID</th>
                                <th>Document Title</th>
                                <th>User</th>
                                <th>Document Name</th>
                                <th>Document Type</th>
                                <th>Version</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>";

                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            $userID = $row["account_id"];
                            $userQuery = "SELECT email FROM accounts WHERE accountID = $userID";
                            $userResult = $mysqli->query($userQuery);
                            $userRow = $userResult->fetch_assoc();

                            echo "<tr>
                                <td>" . $row["document_id"] . "</td>
                                <td>" . $row["document_title"] . "</td>
                                <td>" . $userRow["email"] . "</td>
                                <td>
                                    <a href='#' class='file-link' data-toggle='modal' data-target='#fileModal' data-file='uploadedfiles/{$row["document_name"]}'>{$row["document_name"]}</a>
                                </td>
                                <td>" . $row["document_type"] . "</td>
                                <td>" . $row["version"] . "</td>
                                <td>
                                    <form action='reviewer.php' method='POST'>
                                        <input type='hidden' name='document_id' value='{$row["document_id"]}'>
                                        <textarea name='review_comment' name='comment' class='form-control' placeholder='Add a comment (optional)'></textarea>
                                        <button type='submit' name='reject' class='btn btn-danger mt-2'>Reject</button>
                                        <button type='submit' name='approve' class='btn btn-success mt-2'>Approve</button>

                                    </form>
                                </td>
                            </tr>";
                        }

                        echo "</tbody></table>";
                    } else {
                        echo "<p class='mt-3'>No documents pending review.</p>";
                    }
                }
                if ($user["OfficeID"] == 2) {
                    // Fetch approved documents for OfficeID 2
                    $query = "SELECT t.transactionID, t.documentID, t.reviewerID, t.Office_ID,
                    d.document_title, d.account_id, d.document_name, d.document_type
                    FROM transaction t
                    JOIN document d ON t.documentID = d.document_id
                    WHERE t.statusOfDocument = 'approve'
                      AND t.Office_ID = 1
                      AND t.documentID NOT IN (SELECT documentID FROM transaction WHERE Office_ID = 2)";
                    
                    $result = $mysqli->query($query);
                
                    if ($result->num_rows > 0) {
                        // Display the approved documents in a table
                        echo "<table class='table table-bordered'>
                        <thead class='thead-dark'>
                                <tr>
                                    <th>Transaction ID</th>
                                    <th>Document ID</th>
                                    <th>Reviewer ID</th>
                                    <th>Office ID</th>
                                    <th>Document Title</th>
                                    <th>Account ID</th>
                                    <th>Document Name</th>
                                    <th>Document Type</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>";
                
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>" . $row["transactionID"] . "</td>
                                <td>" . $row["documentID"] . "</td>
                                <td>" . $row["reviewerID"] . "</td>
                                <td>" . $row["Office_ID"] . "</td>
                                <td>" . $row["document_title"] . "</td>
                                <td>" . $row["account_id"] . "</td>
                                <td>
                                    <a href='#' class='file-link' data-toggle='modal' data-target='#fileModal' data-file='uploadedfiles/{$row["document_name"]}'>{$row["document_name"]}</a>
                                </td>
                                <td>" . $row["document_type"] . "</td>
                                <td>
                                    <form action='reviewer.php' method='POST'>
                                        <input type='hidden' name='document_id' value='{$row["documentID"]}'>
                                        <textarea name='review_comment' class='form-control' placeholder='Add a comment (optional)'></textarea>
                                        <button type='submit' name='reject' class='btn btn-danger mt-2'>Reject</button>
                                        <button type='submit' name='approve' class='btn btn-success mt-2'>Approve</button>
                                    </form>
                                </td>
                            </tr>";
                        }
                
                        echo "</tbody></table>";
                    } else {
                        echo "No approved documents found.";
                    }
                }
                
                if ($user["OfficeID"] == 3) {
                    // Fetch documents approved by OfficeID 2 and pending for OfficeID 3
                    $query = "SELECT t.transactionID, t.documentID, t.reviewerID, t.Office_ID,
                    d.document_title, d.account_id, d.document_name, d.document_type
                    FROM transaction t
                    JOIN document d ON t.documentID = d.document_id
                    WHERE t.statusOfDocument = 'approve'
                      AND t.Office_ID = 2
                      AND t.documentID NOT IN (SELECT documentID FROM transaction WHERE Office_ID = 3)";
                
                    $result = $mysqli->query($query);
                
                    if ($result->num_rows > 0) {
                        // Display the approved documents in a table
                        echo "<table class='table table-bordered'>
                        <thead class='thead-dark'>
                                <tr>
                                    <th>Transaction ID</th>
                                    <th>Document ID</th>
                                    <th>Reviewer ID</th>
                                    <th>Office ID</th>
                                    <th>Document Title</th>
                                    <th>Account ID</th>
                                    <th>Document Name</th>
                                    <th>Document Type</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>";
                
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>" . $row["transactionID"] . "</td>
                                    <td>" . $row["documentID"] . "</td>
                                    <td>" . $row["reviewerID"] . "</td>
                                    <td>" . $row["Office_ID"] . "</td>
                                    <td>" . $row["document_title"] . "</td>
                                    <td>" . $row["account_id"] . "</td>
                                    <td>
                                        <a href='#' class='file-link' data-toggle='modal' data-target='#fileModal' data-file='uploadedfiles/{$row["document_name"]}'>{$row["document_name"]}</a>
                                    </td>
                                    <td>" . $row["document_type"] . "</td>
                                    <td>
                                    <form action='reviewer.php' method='POST'>
                                        <input type='hidden' name='document_id' value='{$row["documentID"]}'>
                                        <textarea name='review_comment' class='form-control' placeholder='Add a comment (optional)'></textarea>
                                        <button type='submit' name='reject' class='btn btn-danger mt-2'>Reject</button>
                                        <button type='submit' name='approve' class='btn btn-success mt-2'>Approve</button>
                                    </form>
                                </td>
                                </tr>";
                        }
                        echo "</tbody></table>";
                    } else {
                        echo "No approved documents found.";
                    }
                }
                if ($user["OfficeID"] == 4) {
                    // Fetch documents approved by OfficeID 2 and pending for OfficeID 3
                    $query = "SELECT t.transactionID, t.documentID, t.reviewerID, t.Office_ID,
                    d.document_title, d.account_id, d.document_name, d.document_type
                    FROM transaction t
                    JOIN document d ON t.documentID = d.document_id
                    WHERE t.statusOfDocument = 'approve'
                      AND t.Office_ID = 3
                      AND t.documentID NOT IN (SELECT documentID FROM transaction WHERE Office_ID = 4)";
                
                    $result = $mysqli->query($query);
                
                    if ($result->num_rows > 0) {
                        // Display the approved documents in a table
                        echo "<table class='table table-bordered'>
                        <thead class='thead-dark'>
                                <tr>
                                    <th>Transaction ID</th>
                                    <th>Document ID</th>
                                    <th>Reviewer ID</th>
                                    <th>Office ID</th>
                                    <th>Document Title</th>
                                    <th>Account ID</th>
                                    <th>Document Name</th>
                                    <th>Document Type</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>";
                
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>" . $row["transactionID"] . "</td>
                                    <td>" . $row["documentID"] . "</td>
                                    <td>" . $row["reviewerID"] . "</td>
                                    <td>" . $row["Office_ID"] . "</td>
                                    <td>" . $row["document_title"] . "</td>
                                    <td>" . $row["account_id"] . "</td>
                                    <td>
                                        <a href='#' class='file-link' data-toggle='modal' data-target='#fileModal' data-file='uploadedfiles/{$row["document_name"]}'>{$row["document_name"]}</a>
                                    </td>
                                    <td>" . $row["document_type"] . "</td>
                                    <td>
                        <form action='reviewer.php' method='POST'>
                            <input type='hidden' name='document_id' value='{$row["documentID"]}'>
                            <textarea name='review_comment' class='form-control' placeholder='Add a comment (optional)'></textarea>
                            <button type='submit' name='reject' class='btn btn-danger mt-2'>Reject</button>
                            <button type='submit' name='approve' class='btn btn-success mt-2'>Approve</button>
                        </form>
                    </td>
                    </tr>";
            }
                
                        echo "</tbody></table>";
                    } else {
                        echo "No approved documents found.";
                    }
                }
                if ($user["OfficeID"] == 5) {
                    // Fetch documents approved by OfficeID 2 and pending for OfficeID 3
                    $query = "SELECT t.transactionID, t.documentID, t.reviewerID, t.Office_ID,
                    d.document_title, d.account_id, d.document_name, d.document_type
                    FROM transaction t
                    JOIN document d ON t.documentID = d.document_id
                    WHERE t.statusOfDocument = 'approve'
                      AND t.Office_ID = 4
                      AND t.documentID NOT IN (SELECT documentID FROM transaction WHERE Office_ID = 5)";
                
                    $result = $mysqli->query($query);
                
                    if ($result->num_rows > 0) {
                        // Display the approved documents in a table
                        echo "<table class='table table-bordered'>
                        <thead class='thead-dark'>
                                <tr>
                                    <th>Transaction ID</th>
                                    <th>Document ID</th>
                                    <th>Reviewer ID</th>
                                    <th>Office ID</th>
                                    <th>Document Title</th>
                                    <th>Account ID</th>
                                    <th>Document Name</th>
                                    <th>Document Type</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>";
                
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>" . $row["transactionID"] . "</td>
                                    <td>" . $row["documentID"] . "</td>
                                    <td>" . $row["reviewerID"] . "</td>
                                    <td>" . $row["Office_ID"] . "</td>
                                    <td>" . $row["document_title"] . "</td>
                                    <td>" . $row["account_id"] . "</td>
                                    <td>
                                        <a href='#' class='file-link' data-toggle='modal' data-target='#fileModal' data-file='uploadedfiles/{$row["document_name"]}'>{$row["document_name"]}</a>
                                    </td>
                                    <td>" . $row["document_type"] . "</td>
                                     <td>
                        <form action='reviewer.php' method='POST'>
                            <input type='hidden' name='document_id' value='{$row["documentID"]}'>
                            <textarea name='review_comment' class='form-control' placeholder='Add a comment (optional)'></textarea>
                            <button type='submit' name='reject' class='btn btn-danger mt-2'>Reject</button>
                            <button type='submit' name='approve' class='btn btn-success mt-2'>Approve</button>
                        </form>
                    </td>
                    </tr>";
            }
                        echo "</tbody></table>";
                    } else {
                        echo "No approved documents found.";
                    }
                }
                    ?>
                </div>
                <form action="logout.php" method="POST" class="logout-btn custom-logout-btn">
                    <input type="submit" value="Logout" class="btn btn-danger">
                </form>

                <!-- Add these scripts just before </body> tag -->
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="..." ></script>
                <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
                <script>
                    $(document).ready(function () {
                        $('.file-link').click(function (e) {
                            e.preventDefault();
                            var fileUrl = $(this).data('file');
                            var fileName = $(this).text(); // Get the text content of the link (file name)
                            var documentID = $(this).closest('tr').find('input[name="document_id"]').val();

                            // Set the modal title to the file name
                            $('#fileModalLabel').text('Document Preview - ' + fileName);

                            // Set the iframe source to the file URL
                            $('#fileViewer').attr('src', fileUrl);

                            // Set the document ID in the hidden input field inside the modal
                            $('#modalDocumentID').val(documentID);
                        });

                        $('#fileModal').on('hidden.bs.modal', function () {
                            // Reset the modal title and document ID when the modal is closed
                            $('#fileModalLabel').text('Document Preview');
                            $('#fileViewer').attr('src', '');
                            $('#modalDocumentID').val('');
                        });
                    });
                </script>
        </div>
        <div class="modal fade" id="fileModal" tabindex="-1" role="dialog" aria-labelledby="fileModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl" style="max-width: 90%;" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="fileModalLabel">Document Preview</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <iframe id="fileViewer" width="100%" height="800px" frameborder="0"></iframe>

                        <form action="reviewer.php" method="POST">
                            <div class="form-group mt-3">
                                <label for="comment">Comment (optional):</label>
                                <textarea name="review_comment" id="comment" class="form-control" placeholder="Add a comment (optional)"></textarea>
                            </div>
                            <input type="hidden" name="document_id" id="modalDocumentID">

                            <button type="submit" name="reject" class="btn btn-danger">Reject</button>
                            <button type="submit" name="approve" class="btn btn-success">Approve</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <footer>
        <p>&copy; 2023 ZestyWithTheBesties All rights reserved.</p>                 
    </footer>
</body>

</html>
